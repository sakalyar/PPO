package serie01.model;

public class StdMultiConverter {

}
